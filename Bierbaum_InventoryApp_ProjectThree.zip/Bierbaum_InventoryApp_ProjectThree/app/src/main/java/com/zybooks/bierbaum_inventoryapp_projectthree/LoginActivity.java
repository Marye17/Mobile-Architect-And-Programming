package com.zybooks.bierbaum_inventoryapp_projectthree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private EditText usernameText, passwordText;
    private AccountDAO accountDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


    usernameText = findViewById(R.id.username);
    passwordText = findViewById(R.id.password);
    Button loginButton = findViewById(R.id.logInButton);
    Button createNewAccountButton = findViewById(R.id.createAccountButton);

    accountDAO = new AccountDAO(this);

        loginButton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String username = usernameText.getText().toString();
            String password = passwordText.getText().toString();
            if (accountDAO.existingAccount(username, password)) {
                Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(LoginActivity.this, InventoryGridActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(LoginActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        }
    });

        createNewAccountButton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String username = usernameText.getText().toString();
            String password = passwordText.getText().toString();
            accountDAO.addAccount(username, password);
            Toast.makeText(LoginActivity.this, "User registered", Toast.LENGTH_SHORT).show();
        }
    });
        }
}
