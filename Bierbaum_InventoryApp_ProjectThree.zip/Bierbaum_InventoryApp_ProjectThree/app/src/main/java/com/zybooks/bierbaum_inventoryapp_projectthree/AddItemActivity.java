package com.zybooks.bierbaum_inventoryapp_projectthree;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {
    private ItemDAO itemDAO;
    private EditText nameText, quantityText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        itemDAO = new ItemDAO(this);

        nameText = findViewById(R.id.nameOfItemInput);
        quantityText = findViewById(R.id.quantityOfItemInput);
        Button addItemButton = findViewById(R.id.addItem);

        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameText.getText().toString();
                String number = quantityText.getText().toString();
                Item newItem = new Item(name, number);
                itemDAO.addItem(newItem);
                Intent intent = new Intent(AddItemActivity.this, InventoryGridActivity.class);
                startActivity(intent);
            }
        });
    }
}
