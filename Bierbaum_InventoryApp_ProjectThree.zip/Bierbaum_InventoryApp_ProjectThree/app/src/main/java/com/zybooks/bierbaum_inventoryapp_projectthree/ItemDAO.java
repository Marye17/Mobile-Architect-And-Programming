package com.zybooks.bierbaum_inventoryapp_projectthree;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ItemDAO {
    private SQLiteDatabase inventory;

    public ItemDAO(Context context) {
        InventoryDatabase inventoryDatabase = new InventoryDatabase(context);
        inventory = inventoryDatabase.getWritableDatabase();
    }

    public long addItem(Item item) {
        ContentValues values = new ContentValues();
        values.put(InventoryDatabase.COL_ITEM, item.getName());
        values.put(InventoryDatabase.COL_QUANTITY, item.getQuantity());
        return inventory.insert(InventoryDatabase.TABLE, null, values);
    }

    public int deleteItem(String name) {
        return inventory.delete(InventoryDatabase.TABLE, "name = ?", new String[]{String.valueOf(name)});
    }

    public int updateItem(Item item) {
        ContentValues values = new ContentValues();
        values.put(InventoryDatabase.COL_ITEM, item.getName());
        values.put(InventoryDatabase.COL_QUANTITY, item.getQuantity());
        return inventory.update(InventoryDatabase.TABLE, values, "id = ?", new String[]{String.valueOf(item.getId())});
    }

    public List<Item> getAllItems() {
        List<Item> items = new ArrayList<>();
        Cursor cursor = inventory.query(InventoryDatabase.TABLE, null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryDatabase.COL_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(InventoryDatabase.COL_ITEM));
                String quantity = cursor.getString(cursor.getColumnIndexOrThrow(InventoryDatabase.COL_QUANTITY));
                items.add(new Item(name, quantity));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return items;
    }


}
