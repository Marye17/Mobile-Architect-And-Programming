package com.zybooks.bierbaum_inventoryapp_projectthree;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InventoryGridActivity extends AppCompatActivity {

    private  ItemDAO itemDAO;
    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_grid);

        Button addItemButton = findViewById(R.id.addItemButton);
        itemDAO = new ItemDAO(this);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));

        List<Item> items = itemDAO.getAllItems();
        itemAdapter = new ItemAdapter(items);
        recyclerView.setAdapter(itemAdapter);

        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InventoryGridActivity.this, AddItemActivity.class);
                startActivity(intent);
            }
        });

    }

}
