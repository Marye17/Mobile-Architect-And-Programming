package com.zybooks.bierbaum_inventoryapp_projectthree;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class InventoryDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;

    public static final String TABLE = "inventory";
    public static final String COL_ID = "_id";
    public static final String COL_ITEM = "item";
    public static final String COL_QUANTITY = "quantity";

    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE + " (" +
                COL_ID + " integer primary key autoincrement, " +
                COL_ITEM + " text, " +
                COL_QUANTITY + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + TABLE);
        onCreate(db);
    }
}