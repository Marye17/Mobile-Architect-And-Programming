package com.zybooks.bierbaum_inventoryapp_projectthree;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class AccountDAO {
    private AuthenticationDatabase authenticationDatabase;
    private SQLiteDatabase accounts;

    public AccountDAO(Context context) {
        authenticationDatabase = new AuthenticationDatabase(context);
        accounts = authenticationDatabase.getWritableDatabase();
    }

    public void addAccount(String username, String password) {
        ContentValues values = new ContentValues();
        values.put(AuthenticationDatabase.COL_USERNAME, username);
        values.put(AuthenticationDatabase.COL_PASSWORD, password);
        accounts.insert(AuthenticationDatabase.TABLE, null, values);
    }

    public boolean existingAccount(String username, String password) {
        String[] columns = { AuthenticationDatabase.COL_ID };
        String selection = AuthenticationDatabase.COL_USERNAME + " = ? AND " + AuthenticationDatabase.COL_PASSWORD + " = ?";
        String[] selectionArgs = { username, password };
        Cursor cursor = accounts.query(AuthenticationDatabase.TABLE, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }


}
